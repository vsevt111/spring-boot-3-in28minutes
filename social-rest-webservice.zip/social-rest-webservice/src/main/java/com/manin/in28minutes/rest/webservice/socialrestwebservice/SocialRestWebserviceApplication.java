package com.manin.in28minutes.rest.webservice.socialrestwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialRestWebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialRestWebserviceApplication.class, args);
	}

}
