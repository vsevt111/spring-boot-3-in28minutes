package com.manin.in28minutes.rest.webservice.socialrestwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialRestWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
