package com.manin.in28minutes.spring.aop.learnspringaop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
