package com.manin.in28minutes.springboot.todowebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodowebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
