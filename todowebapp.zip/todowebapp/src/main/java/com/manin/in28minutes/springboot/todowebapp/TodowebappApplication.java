package com.manin.in28minutes.springboot.todowebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodowebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodowebappApplication.class, args);
	}

}
