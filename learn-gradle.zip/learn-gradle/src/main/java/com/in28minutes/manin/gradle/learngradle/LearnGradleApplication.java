package com.in28minutes.manin.gradle.learngradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnGradleApplication.class, args);
	}

}
